import 'package:flutter/material.dart';

class TelaPragas extends StatelessWidget {
  const TelaPragas({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pragas & Doenças')),
      body: const Center(child: Text('Em breve: base de conhecimento + recomendações.')),
    );
  }
}
