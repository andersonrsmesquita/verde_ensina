import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

import '../firebase/firebase_paths.dart';
import 'app_session.dart';

/// Estado alto nível da sessão.
///
/// - signedOut: sem usuário logado
/// - loading: carregando userDoc / membership
/// - needsTenant: logado, mas ainda não escolheu/criou um tenant
/// - ready: sessão pronta (uid + tenantId + scopes)
/// - error: erro ao carregar sessão
enum SessionStatus {
  signedOut,
  loading,
  needsTenant,
  ready,
  error,
}

class SessionController extends ChangeNotifier {
  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  SessionController({
    FirebaseAuth? auth,
    FirebaseFirestore? db,
  })  : _auth = auth ?? FirebaseAuth.instance,
        _db = db ?? FirebaseFirestore.instance;

  StreamSubscription<User?>? _authSub;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _userSub;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _memberSub;

  bool _ready = false;
  bool get ready => _ready;

  Object? _error;
  Object? get error => _error;

  AppSession? _session;
  AppSession? get session => _session;

  SessionStatus _status = SessionStatus.loading;
  SessionStatus get status => _status;

  DocumentSnapshot<Map<String, dynamic>>? _userDoc;
  DocumentSnapshot<Map<String, dynamic>>? get userDoc => _userDoc;

  String? get uid => _auth.currentUser?.uid;
  bool get isLoggedIn => uid != null;

  Future<void> init() async {
    await _authSub?.cancel();

    // primeiro estado (boot)
    _onAuth(_auth.currentUser);

    // depois continua ouvindo mudanças
    _authSub = _auth.authStateChanges().listen(_onAuth);
  }

  void _onAuth(User? user) {
    _userSub?.cancel();
    _memberSub?.cancel();

    _session = null;
    _userDoc = null;
    _error = null;
    _ready = false;

    if (user == null) {
      _status = SessionStatus.signedOut;
      _ready = true;
      notifyListeners();
      return;
    }

    _status = SessionStatus.loading;
    notifyListeners();

    // garante user doc
    final uref = FirebasePaths.userRef(user.uid);
    _userSub = uref.snapshots().listen((snap) async {
      try {
        if (!snap.exists) {
          await uref.set({
            'createdAt': FieldValue.serverTimestamp(),
            'updatedAt': FieldValue.serverTimestamp(),
            'currentTenantId': null,
            'defaultTenantId': null,
            'tenantIds': <String>[],
          }, SetOptions(merge: true));
        }

        _userDoc = snap;

        final data = snap.data() ?? {};
        final currentTenantId = (data['currentTenantId'] ?? '').toString();
        final defaultTenantId = (data['defaultTenantId'] ?? '').toString();

        final tenantId = currentTenantId.isNotEmpty
            ? currentTenantId
            : (defaultTenantId.isNotEmpty ? defaultTenantId : '');

        if (tenantId.isEmpty) {
          // logou, mas ainda não escolheu/criou tenant
          _session = null;
          _ready = true;
          _status = SessionStatus.needsTenant;
          _error = null;
          notifyListeners();
          return;
        }

        _listenMembership(user.uid, tenantId);
      } catch (e) {
        _error = e;
        _session = null;
        _ready = true;
        _status = SessionStatus.error;
        notifyListeners();
      }
    });
  }

  void _listenMembership(String uid, String tenantId) {
    _memberSub?.cancel();

    _status = SessionStatus.loading;
    _ready = false;
    notifyListeners();

    _memberSub = FirebasePaths.memberRef(tenantId, uid).snapshots().listen((snap) {
      try {
        if (!snap.exists) {
          // usuário tá apontando pra um tenant que ele não participa
          _session = null;
          _ready = true;
          _status = SessionStatus.needsTenant;
          notifyListeners();
          return;
        }

        final m = snap.data() ?? {};
        final active = (m['active'] ?? true) == true;
        if (!active) {
          _session = null;
          _error = Exception('Conta inativa nesse espaço.');
          _ready = true;
          _status = SessionStatus.error;
          notifyListeners();
          return;
        }

        final scopesRaw = (m['scopes'] is List) ? (m['scopes'] as List) : <dynamic>[];
        final scopes = scopesRaw.map((e) => e.toString()).toList();

        _session = AppSession(uid: uid, tenantId: tenantId, scopes: scopes);
        _ready = true;
        _error = null;
        _status = SessionStatus.ready;
        notifyListeners();
      } catch (e) {
        _error = e;
        _session = null;
        _ready = true;
        _status = SessionStatus.error;
        notifyListeners();
      }
    });
  }

  Future<void> selectTenant(String tenantId) async {
    final u = _auth.currentUser;
    if (u == null) return;

    await FirebasePaths.userRef(u.uid).set({
      'currentTenantId': tenantId,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<String> createTenant({
    required String name,
  }) async {
    final u = _auth.currentUser;
    if (u == null) throw Exception('Usuário não logado');

    final tenantRef = FirebasePaths.tenantsCol().doc();
    final uid = u.uid;

    await _db.runTransaction((tx) async {
      tx.set(tenantRef, {
        'name': name,
        'status': 'active',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'ownerUid': uid,
        // SaaS baseline
        'subscriptionStatus': 'trial',
        'trialEndsAt': Timestamp.fromDate(DateTime.now().add(const Duration(days: 14))),
        'modulesEnabled': {
          'canteiros': true,
          'solo': true,
          'irrigacao': true,
          'pragas': true,
          'planejamento': true,
          'mercado': false,
          'financeiro': false,
        },
      });

      tx.set(tenantRef.collection('members').doc(uid), {
        'uid': uid,
        'role': 'owner',
        'active': true,
        'scopes': [
          'tenant:admin',
          'canteiros:edit',
          'canteiros:view',
          'manejo:edit',
          'manejo:view',
          'financeiro:view',
          'financeiro:edit',
        ],
        'createdAt': FieldValue.serverTimestamp(),
      });

      tx.set(
        FirebasePaths.userRef(uid),
        {
          'defaultTenantId': tenantRef.id,
          'currentTenantId': tenantRef.id,
          'tenantIds': FieldValue.arrayUnion([tenantRef.id]),
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
    });

    return tenantRef.id;
  }

  /// Sai da conta e reseta o estado local.
  Future<void> signOut() async {
    try {
      await _auth.signOut();
    } finally {
      // força reset imediato
      _onAuth(null);
    }
  }

  @override
  void dispose() {
    _authSub?.cancel();
    _userSub?.cancel();
    _memberSub?.cancel();
    super.dispose();
  }
}
