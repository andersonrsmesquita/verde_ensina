import 'package:flutter/material.dart';

class TelaIrrigacao extends StatelessWidget {
  const TelaIrrigacao({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Irrigação')),
      body: const Center(child: Text('Em breve: regras simples + histórico.')),
    );
  }
}
